﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// DlgSample.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_DlgSampleTYPE               130
#define IDD_TEST                        311
#define IDD_MODELESS                    312
#define IDC_EDIT1                       1000
#define IDC_EDIT_NAME                   1000
#define IDC_EDIT_PWD                    1001
#define IDC_EDIT_AGE                    1003
#define IDC_EDIT_READONLY               1004
#define ID_TEST_TEST                    32771
#define ID_TEST_MODELESS                32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        313
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
