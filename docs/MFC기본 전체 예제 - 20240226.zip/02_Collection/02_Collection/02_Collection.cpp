﻿#define _AFXDLL
#include <afx.h>
#include <Afxtempl.h>
#include <iostream>

int main()
{
	return 0;
}
